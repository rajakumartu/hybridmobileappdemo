export { default } from './EditorToolbar';

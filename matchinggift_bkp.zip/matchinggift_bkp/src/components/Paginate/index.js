export { default } from './Paginate';

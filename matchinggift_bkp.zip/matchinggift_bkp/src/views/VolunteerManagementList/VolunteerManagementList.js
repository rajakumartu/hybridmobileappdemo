import React, { useState, useEffect } from 'react';
import { makeStyles } from '@material-ui/styles';

import axios from 'utils/axios';
import { Page, SearchBar } from 'components';
import { Header, Results } from './components';

const useStyles = makeStyles(theme => ({
  root: {
    padding: theme.spacing(3)
  },
  results: {
    marginTop: theme.spacing(3)
  }
}));

const VolunteerManagementList = () => {
  const classes = useStyles();

  const [volunteers, setVolunteer] = useState([]);

  useEffect(() => {
    let mounted = true;

    const fetchVolunteers = () => {
      axios.get('/api/management/volunteers').then(response => {
        if (mounted) {
          setVolunteer(response.data.volunteers);
          console.log(response.data.volunteers);
        }
      });
    };

    fetchVolunteers();

    return () => {
      mounted = false;
    };
  }, []);

  const handleFilter = () => {};
  const handleSearch = () => {};

  return (
    <Page
      className={classes.root}
      title="Volunteer Management List"
    >
      <Header />
      <SearchBar
        onFilter={handleFilter}
        onSearch={handleSearch}
      />
      {volunteers && (
        <Results
          className={classes.results}
          volunteers={volunteers}
        />
      )}
    </Page>
  );
};

export default VolunteerManagementList;

import React, { useState } from 'react';
import { Link as RouterLink } from 'react-router-dom';
import clsx from 'clsx';
import PropTypes from 'prop-types';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { makeStyles } from '@material-ui/styles';
import {
  Avatar,
  Card,
  CardActions,
  CardContent,
  CardHeader,
  Checkbox,
  Divider,
  Button,
  Link,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TablePagination,
  TableRow,
  Typography
} from '@material-ui/core';

import getInitials from 'utils/getInitials';
import { ReviewStars, GenericMoreButton, TableEditBar } from 'components';

const useStyles = makeStyles(theme => ({
  root: {},
  content: {
    padding: 0
  },
  inner: {
    minWidth: 700
  },
  nameCell: {
    display: 'flex',
    alignItems: 'center'
  },
  avatar: {
    height: 42,
    width: 42,
    marginRight: theme.spacing(1)
  },
  actions: {
    padding: theme.spacing(1),
    justifyContent: 'flex-end'
  }
}));

const Results = props => {
  const { className, volunteers, ...rest } = props;
  const classes = useStyles();

  const [selectedVolunteers, setSelectedVolunteers] = useState([]);
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);

  const handleSelectAll = event => {
    const selectedVolunteers = event.target.checked
      ? volunteers.map(volunteer => volunteer.id)
      : [];

    setSelectedVolunteers(selectedVolunteers);
  };

  const handleSelectOne = (event, id) => {
    const selectedIndex = selectedVolunteers.indexOf(id);
    let newSelectedVolunteers = [];

    if (selectedIndex === -1) {
      newSelectedVolunteers = newSelectedVolunteers.concat(selectedVolunteers, id);
    } else if (selectedIndex === 0) {
      newSelectedVolunteers = newSelectedVolunteers.concat(
        selectedVolunteers.slice(1)
      );
    } else if (selectedIndex === selectedVolunteers.length - 1) {
      newSelectedVolunteers = newSelectedVolunteers.concat(
        selectedVolunteers.slice(0, -1)
      );
    } else if (selectedIndex > 0) {
      newSelectedVolunteers = newSelectedVolunteers.concat(
        selectedVolunteers.slice(0, selectedIndex),
        selectedVolunteers.slice(selectedIndex + 1)
      );
    }

    setSelectedVolunteers(newSelectedVolunteers);
  };

  const handleChangePage = (event, page) => {
    setPage(page);
  };

  const handleChangeRowsPerPage = event => {
    setRowsPerPage(event.target.value);
  };

  return (
    <div
      {...rest}
      className={clsx(classes.root, className)}
    >
      <Typography
        color="textSecondary"
        gutterBottom
        variant="body2"
      >
        {volunteers.length} Records found. Page {page + 1} of{' '}
        {Math.ceil(volunteers.length / rowsPerPage)}
      </Typography>
      <Card>
        <CardHeader
          action={<GenericMoreButton />}
          title="All volunteers"
        />
        <Divider />
        <CardContent className={classes.content}>
          <PerfectScrollbar>
            <div className={classes.inner}>
              <Table>
                <TableHead>
                  <TableRow>
                    <TableCell padding="checkbox">
                      <Checkbox
                        checked={selectedVolunteers.length === volunteers.length}
                        color="primary"
                        indeterminate={
                          selectedVolunteers.length > 0 &&
                          selectedVolunteers.length < volunteers.length
                        }
                        onChange={handleSelectAll}
                      />
                    </TableCell>
                    <TableCell>Name</TableCell>
                    <TableCell>Location</TableCell>
                    <TableCell>Gender</TableCell>
                    <TableCell>Profession</TableCell>
                    <TableCell>Projects held</TableCell>
                    <TableCell align="right">Actions</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {volunteers.slice(0, rowsPerPage).map(volunteer => (
                    <TableRow
                      hover
                      key={volunteer.id}
                      selected={selectedVolunteers.indexOf(volunteer.id) !== -1}
                    >
                      <TableCell padding="checkbox">
                        <Checkbox
                          checked={
                            selectedVolunteers.indexOf(volunteer.id) !== -1
                          }
                          color="primary"
                          onChange={event =>
                            handleSelectOne(event, volunteer.id)
                          }
                          value={selectedVolunteers.indexOf(volunteer.id) !== -1}
                        />
                      </TableCell>
                      <TableCell>
                        <div className={classes.nameCell}>
                          <Avatar
                            className={classes.avatar}
                            src={volunteer.avatar}
                          >
                            {getInitials(volunteer.name)}
                          </Avatar>
                          <div>
                            <Link
                              color="inherit"
                              component={RouterLink}
                              to="/management/volunteers/1"
                              variant="h6"
                            >
                              {volunteer.name}
                            </Link>
                            <div>{volunteer.email}</div>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>{volunteer.location}</TableCell>
                      <TableCell>
                        {volunteer.gender}
                      </TableCell>
                      <TableCell>{volunteer.profession}</TableCell>
                      <TableCell>{volunteer.projects}</TableCell>
                      <TableCell align="right">
                        <Button
                          color="primary"
                          component={RouterLink}
                          size="small"
                          to="/management/volunteers/1"
                          variant="outlined"
                        >
                          View
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </PerfectScrollbar>
        </CardContent>
        <CardActions className={classes.actions}>
          <TablePagination
            component="div"
            count={volunteers.length}
            onChangePage={handleChangePage}
            onChangeRowsPerPage={handleChangeRowsPerPage}
            page={page}
            rowsPerPage={rowsPerPage}
            rowsPerPageOptions={[5, 10, 25]}
          />
        </CardActions>
      </Card>
      <TableEditBar selected={selectedVolunteers} />
    </div>
  );
};

Results.propTypes = {
  className: PropTypes.string,
  volunteers: PropTypes.array.isRequired
};

Results.defaultProps = {
  volunteers: []
};

export default Results;

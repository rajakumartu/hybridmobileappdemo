export { default } from './InvoiceDetails';

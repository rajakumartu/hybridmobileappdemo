export { default as Chart } from './Chart';

import React, { useState } from 'react';
import { Link as RouterLink } from 'react-router-dom';
import clsx from 'clsx';
import PropTypes from 'prop-types';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { makeStyles } from '@material-ui/styles';
import {
  Avatar,
  Card,
  CardActions,
  CardContent,
  CardHeader,
  Checkbox,
  Divider,
  Button,
  Link,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TablePagination,
  TableRow,
  Typography
} from '@material-ui/core';

import getInitials from 'utils/getInitials';
import { ReviewStars, GenericMoreButton, TableEditBar } from 'components';

const useStyles = makeStyles(theme => ({
  root: {},
  content: {
    padding: 0
  },
  inner: {
    minWidth: 700
  },
  nameCell: {
    display: 'flex',
    alignItems: 'center'
  },
  avatar: {
    height: 42,
    width: 42,
    marginRight: theme.spacing(1)
  },
  actions: {
    padding: theme.spacing(1),
    justifyContent: 'flex-end'
  }
}));

const Results = props => {
  const { className, ngos, ...rest } = props;
  const classes = useStyles();

  const [selectedNgos, setSelectedNgos] = useState([]);
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);

  const handleSelectAll = event => {
    const selectedNgos = event.target.checked
      ? ngos.map(ngo => ngo.id)
      : [];

    setSelectedNgos(selectedNgos);
  };

  const handleSelectOne = (event, id) => {
    const selectedIndex = selectedNgos.indexOf(id);
    let newSelectedNgos = [];

    if (selectedIndex === -1) {
      newSelectedNgos = newSelectedNgos.concat(selectedNgos, id);
    } else if (selectedIndex === 0) {
      newSelectedNgos = newSelectedNgos.concat(
        selectedNgos.slice(1)
      );
    } else if (selectedIndex === selectedNgos.length - 1) {
      newSelectedNgos = newSelectedNgos.concat(
        selectedNgos.slice(0, -1)
      );
    } else if (selectedIndex > 0) {
      newSelectedNgos = newSelectedNgos.concat(
        selectedNgos.slice(0, selectedIndex),
        selectedNgos.slice(selectedIndex + 1)
      );
    }

    setSelectedNgos(newSelectedNgos);
  };

  const handleChangePage = (event, page) => {
    setPage(page);
  };

  const handleChangeRowsPerPage = event => {
    setRowsPerPage(event.target.value);
  };

  return (
    <div
      {...rest}
      className={clsx(classes.root, className)}
    >
      <Typography
        color="textSecondary"
        gutterBottom
        variant="body2"
      >
        {ngos.length} Records found. Page {page + 1} of{' '}
        {Math.ceil(ngos.length / rowsPerPage)}
      </Typography>
      <Card>
        <CardHeader
          action={<GenericMoreButton />}
          title="All ngos"
        />
        <Divider />
        <CardContent className={classes.content}>
          <PerfectScrollbar>
            <div className={classes.inner}>
              <Table>
                <TableHead>
                  <TableRow>
                    <TableCell padding="checkbox">
                      <Checkbox
                        checked={selectedNgos.length === ngos.length}
                        color="primary"
                        indeterminate={
                          selectedNgos.length > 0 &&
                          selectedNgos.length < ngos.length
                        }
                        onChange={handleSelectAll}
                      />
                    </TableCell>
                    <TableCell>Name</TableCell>
                    <TableCell>Location</TableCell>
                    <TableCell>Profession</TableCell>
                    <TableCell>Projects held</TableCell>
                    <TableCell align="right">Actions</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {ngos.slice(0, rowsPerPage).map(ngo => (
                    <TableRow
                      hover
                      key={ngo.id}
                      selected={selectedNgos.indexOf(ngo.id) !== -1}
                    >
                      <TableCell padding="checkbox">
                        <Checkbox
                          checked={
                            selectedNgos.indexOf(ngo.id) !== -1
                          }
                          color="primary"
                          onChange={event =>
                            handleSelectOne(event, ngo.id)
                          }
                          value={selectedNgos.indexOf(ngo.id) !== -1}
                        />
                      </TableCell>
                      <TableCell>
                        <div className={classes.nameCell}>
                          <Avatar
                            className={classes.avatar}
                            src={ngo.avatar}
                          >
                            {getInitials(ngo.name)}
                          </Avatar>
                          <div>
                            <Link
                              color="inherit"
                              component={RouterLink}
                              to="/management/ngos/1"
                              variant="h6"
                            >
                              {ngo.name}
                            </Link>
                            <div>{ngo.email}</div>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>{ngo.location}</TableCell>
                      <TableCell>{ngo.focus}</TableCell>
                      <TableCell>{ngo.projects}</TableCell>
                      <TableCell align="right">
                        <Button
                          color="primary"
                          component={RouterLink}
                          size="small"
                          to="/management/ngos/1"
                          variant="outlined"
                        >
                          View
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </PerfectScrollbar>
        </CardContent>
        <CardActions className={classes.actions}>
          <TablePagination
            component="div"
            count={ngos.length}
            onChangePage={handleChangePage}
            onChangeRowsPerPage={handleChangeRowsPerPage}
            page={page}
            rowsPerPage={rowsPerPage}
            rowsPerPageOptions={[5, 10, 25]}
          />
        </CardActions>
      </Card>
      <TableEditBar selected={selectedNgos} />
    </div>
  );
};

Results.propTypes = {
  className: PropTypes.string,
  ngos: PropTypes.array.isRequired
};

Results.defaultProps = {
  ngos: []
};

export default Results;

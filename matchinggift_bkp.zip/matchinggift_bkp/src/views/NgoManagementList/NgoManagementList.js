import React, { useState, useEffect } from 'react';
import { makeStyles } from '@material-ui/styles';

import axios from 'utils/axios';
import { Page, SearchBar } from 'components';
import { Header, Results } from './components';

const useStyles = makeStyles(theme => ({
  root: {
    padding: theme.spacing(3)
  },
  results: {
    marginTop: theme.spacing(3)
  }
}));

const NgoManagementList = () => {
  const classes = useStyles();

  const [ngos, setNgo] = useState([]);

  useEffect(() => {
    let mounted = true;

    const fetchNgos = () => {
      axios.get('/api/management/ngos').then(response => {
        if (mounted) {
          setNgo(response.data.ngos);
          console.log(response.data.ngos);
        }
      });
    };

    fetchNgos();

    return () => {
      mounted = false;
    };
  }, []);

  const handleFilter = () => {};
  const handleSearch = () => {};

  return (
    <Page
      className={classes.root}
      title="Ngo Management List"
    >
      <Header />
      <SearchBar
        onFilter={handleFilter}
        onSearch={handleSearch}
      />
      {ngos && (
        <Results
          className={classes.results}
          ngos={ngos}
        />
      )}
    </Page>
  );
};

export default NgoManagementList;

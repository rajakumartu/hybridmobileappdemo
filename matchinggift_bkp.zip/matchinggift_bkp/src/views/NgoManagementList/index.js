export { default } from './NgoManagementList'

export { default } from './CustomerManagementDetails';

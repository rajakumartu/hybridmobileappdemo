export { default } from './CustomerManagementList';

export { default } from './WishManagementList';

export { default } from './Wishes';

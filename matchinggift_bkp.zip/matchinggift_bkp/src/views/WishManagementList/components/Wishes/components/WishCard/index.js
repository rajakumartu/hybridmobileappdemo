export { default } from './WishCard';

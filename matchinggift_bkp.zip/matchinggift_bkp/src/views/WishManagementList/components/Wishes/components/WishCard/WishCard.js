import React from 'react';
import { Link as RouterLink } from 'react-router-dom';
import PropTypes from 'prop-types';
import clsx from 'clsx';
import { makeStyles } from '@material-ui/styles';
import {
  Typography,
  Card,
  CardMedia,
  CardContent,
  Grid,
  Divider,
  Avatar
} from '@material-ui/core';

import { Label } from 'components';

const useStyles = makeStyles(theme => ({
  root: {},
  media: {
    height: 125
  },
  content: {
    paddingTop: 0
  },
  avatarContainer: {
    marginTop: -32,
    display: 'flex',
    justifyContent: 'center'
  },
  avatar: {
    height: 64,
    width: 64,
    borderWidth: 4,
    borderStyle: 'solid',
    borderColor: theme.palette.white
  },
  message: {
    padding: theme.spacing(2, 3)
  },
  divider: {
    margin: theme.spacing(2, 0)
  }
}));

const WishCard = props => {
  const { wish, className, ...rest } = props;

  const classes = useStyles();

  return (
    <Card
      {...rest}
      className={clsx(classes.root, className)}
    >
      <CardMedia
        className={classes.media}
        image={wish.cover_pic}
      />
      <CardContent className={classes.content}>
        <div className={classes.avatarContainer}>
          <Avatar
            alt="Wish"
            className={classes.avatar}
            component={RouterLink}
            src={wish.requestor.avatar}
            to="/profile/1/timeline"
          />
        </div>
        <Typography
          align="center"
          component={RouterLink}
          display="block"
          to="/profile/1/timeline"
          variant="h6"
        >
          {wish.requestor.name}
        </Typography>
        <Typography
          align="center"
          variant="body2"
        >
          {wish.title}
        </Typography>
        <div className={classes.message}>
          <Typography variant="subtitle2">"{wish.requestor.message}"</Typography>
        </div>
        <Divider className={classes.divider} />
        <Grid
          alignItems="center"
          container
          justify="space-between"
          spacing={3}
        >
          <Grid item>
              <Typography variant="h5">{wish.requestor.class}</Typography>
              <Typography variant="body2">Class</Typography>
            </Grid>
            <Grid item>
              <Typography variant="h5">{wish.ngo.name}</Typography>
              <Typography variant="body2">NGO</Typography>
            </Grid>
            <Grid item>
            <div className={classes.tags}>
            <Label
              color={wish.status.color}
            >
              {wish.status.text}
            </Label>
          </div>
          </Grid>
        </Grid>
      </CardContent>
    </Card>
  );
};

WishCard.propTypes = {
  className: PropTypes.string,
  wish: PropTypes.object.isRequired
};

export default WishCard;

export { default as WishCard } from './WishCard';

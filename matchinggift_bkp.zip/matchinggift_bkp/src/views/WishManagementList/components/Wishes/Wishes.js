import React from 'react';
import PropTypes from 'prop-types';
import clsx from 'clsx';
import { makeStyles } from '@material-ui/styles';
import { Grid } from '@material-ui/core';

import { WishCard } from './components';

const useStyles = makeStyles(() => ({
  root: {}
}));

const Wishes = props => {
  const { wishes, className, ...rest } = props;

  const classes = useStyles();

  return (
    <Grid
      {...rest}
      className={clsx(classes.root, className)}
      container
      spacing={3}
    >
      {wishes.map(wish => (
        <Grid
          item
          key={wish.id}
          lg={4}
          xs={12}
        >
          <WishCard wish={wish} />
        </Grid>
      ))}
    </Grid>
  );
};

Wishes.propTypes = {
  className: PropTypes.string,
  wishes: PropTypes.array.isRequired
};

export default Wishes;

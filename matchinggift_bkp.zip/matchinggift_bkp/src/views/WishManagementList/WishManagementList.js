import React, { useState, useEffect } from 'react';
import { Redirect } from 'react-router-dom';
import PropTypes from 'prop-types';
import { makeStyles } from '@material-ui/styles';
import { Tabs, Tab, Divider, colors } from '@material-ui/core';

import axios from 'utils/axios';
import { Page, Alert } from 'components';
import { Header, Wishes } from './components';

const useStyles = makeStyles(theme => ({
  root: {
    width: theme.breakpoints.values.lg,
    maxWidth: '100%',
    margin: '0 auto',
    padding: theme.spacing(3)
  },
  tabs: {
    marginTop: theme.spacing(3)
  },
  divider: {
    backgroundColor: colors.grey[300]
  },
  alert: {
    marginTop: theme.spacing(3)
  },
  content: {
    marginTop: theme.spacing(3)
  }
}));

const WishManagementList = props => {
  const { match, history } = props;
  const classes = useStyles();
  const { id, tab } = match.params;
  const [openAlert, setOpenAlert] = useState(true);
  const [wishes, setWishes] = useState(null);

  useEffect(() => {
    let mounted = true;

    const fetchWishes = () => {
      axios.get('/api/wishes').then(response => {
        if (mounted) {
          debugger;
          setWishes(response.data.wishes);
        }
      });
    };

    fetchWishes();

    return () => {
      mounted = false;
    };
  }, []);

  const handleAlertClose = () => {
    setOpenAlert(false);
  };

  const handleTabsChange = (event, value) => {
    history.push(value);
  };

  return (
    <Page
      className={classes.root}
      title="Management"
    >
      <Header />
      <Divider className={classes.divider} />
      {openAlert && (
        <Alert
          className={classes.alert}
          message="New Wishes have been added ! Fullfill and make a difference !!! "
          onClose={handleAlertClose}
        />
      )}
      <div className={classes.content}>
        {wishes ? ( <Wishes wishes={wishes} /> ) : (<></> )}
          
      </div>
    </Page>
  );
};

WishManagementList.propTypes = {
  history: PropTypes.object.isRequired,
  match: PropTypes.object.isRequired
};

export default WishManagementList;

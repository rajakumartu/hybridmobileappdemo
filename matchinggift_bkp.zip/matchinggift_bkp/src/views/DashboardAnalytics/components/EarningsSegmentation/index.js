export { default } from './EarningsSegmentation';

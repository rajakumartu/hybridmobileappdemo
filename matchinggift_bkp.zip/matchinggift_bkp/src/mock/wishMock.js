import uuid from 'uuid/v1';
import moment from 'moment';
import { colors } from '@material-ui/core';

import mock from 'utils/mock';

mock.onGet('/api/wishes').reply(200, {
  wishes: [
    {
      id: uuid(),
      title: 'Smartphone for Online Classes',
      cover_pic: '/images/covers/wish/phone2.jpeg',
      ngo: {
        name: 'Team Everest',
      },
      requestor: {
        name: 'Hari Priya',
        class: '5th Standard',
        message: 'I Need a Smartphone to attend my online classes',
        avatar: '/images/avatars/wish/kid2.png',
      },
      location: 'Chennai',
      status: {
        text: 'Not Fulfilled',
        color: colors.red[600]
      },
      requested_date: moment()
    },
    {
      id: uuid(),
      title: 'Headset to listen to words for Blind',
      cover_pic: '/images/covers/wish/headset.jpeg',
      ngo: {
        name: 'Chennai Volunteers',
      },
      requestor: {
        name: 'Karthika',
        class: '7th Standard',
        message: 'Please !! Help me with a smartphone to I can listen to new words to learn',
        avatar: '/images/avatars/wish/kid3.png',
      },
      location: 'Chennai',
      status: {
        text: 'Inititated',
        color: colors.orange[600]
      },
      requested_date: moment()
    },
    {
      id: uuid(),
      title: 'Laptop to learn programming',
      cover_pic: '/images/covers/wish/laptop.jpeg',
      ngo: {
        name: 'Anudip',
      },
      requestor: {
        name: 'Harish',
        class: '12th Standard',
        message: 'I Need a laptop to learn and parctice java programming',
        avatar: '/images/avatars/wish/kid4.png',
      },
      location: 'Chennai',
      status: {
        text: 'Fullfilled',
        color: colors.green[600]
      },
      requested_date: moment()
    }
  ]});

import uuid from 'uuid/v1';
import moment from 'moment';

import mock from 'utils/mock';

mock.onGet('/api/chat/conversations').reply(200, {
  conversations: [
    {
      id: uuid(),
      otherUser: {
        name: 'Adam Denisov',
        avatar: '/images/avatars/volunteers/molestiasseddebitis.png',
        active: true,
        lastActivity: moment()
      },
      messages: [
        {
          id: uuid(),
          sender: {
            authUser: false,
            name: 'Adam Denisov',
            avatar: '/images/avatars/volunteers/molestiasseddebitis.png',
            lastActivity: moment()
          },
          content:
            'Hey, nice projects! I really liked the one in react. What\'s your quote on kinda similar project?',
          contentType: 'text',
          created_at: moment().subtract(10, 'hours')
        },
        {
          id: uuid(),
          sender: {
            authUser: true,
            name: 'Rajakumar Thangavelu',
            avatar: '/images/avatars/volunteers/rajakumar.thangavelu.jpg'
          },
          content:
            'I would need to know more details, but my hourly rate stats at $35/hour. Thanks!',
          contentType: 'text',
          created_at: moment().subtract(2, 'hours')
        },
        {
          id: uuid(),
          sender: {
            authUser: false,
            name: 'Adam Denisov',
            avatar: '/images/avatars/volunteers/molestiasseddebitis.png'
          },
          content:
            'Well it\'s a really easy one, I\'m sure we can make it half of the price.',
          contentType: 'text',
          created_at: moment().subtract(5, 'minutes')
        },
        {
          id: uuid(),
          sender: {
            authUser: true,
            name: 'Rajakumar Thangavelu',
            avatar: '/images/avatars/volunteers/rajakumar.thangavelu.jpg'
          },
          content:
            'Then why don\'t you make it if it\'s that easy? Sorry I\'m not interetes, have fantastic day Adam!',
          contentType: 'text',
          created_at: moment().subtract(3, 'minutes')
        },
        {
          id: uuid(),
          sender: {
            authUser: false,
            name: 'Adam Denisov',
            avatar: '/images/avatars/volunteers/molestiasseddebitis.png'
          },
          content: 'Last offer, $25 per hour',
          contentType: 'text',
          created_at: moment().subtract(1, 'minute')
        },
        {
          id: uuid(),
          sender: {
            authUser: false,
            name: 'Adam Denisov',
            avatar: '/images/avatars/volunteers/molestiasseddebitis.png'
          },
          content: '/images/projects/project_1.jpg',
          contentType: 'image',
          created_at: moment().subtract(1, 'minute')
        }
      ],
      unread: 0,
      created_at: moment().subtract(1, 'minute')
    },
    {
      id: uuid(),
      otherUser: {
        name: 'Ekaterina Tankova',
        avatar: '/images/avatars/volunteers/estfugitaut.png',
        active: true,
        lastActivity: moment()
      },
      messages: [
        {
          id: uuid(),
          sender: {
            authUser: true,
            name: 'Rajakumar Thangavelu',
            avatar: '/images/avatars/volunteers/rajakumar.thangavelu.jpg'
          },
          content: 'Hey, would you like to collaborate?',
          contentType: 'text',
          created_at: moment().subtract(6, 'minutes')
        },
        {
          id: uuid(),
          sender: {
            authUser: false,
            name: 'Ekaterina Tankova',
            avatar: '/images/avatars/volunteers/estfugitaut.png'
          },
          content: 'I don\'t think that\'s ideal',
          contentType: 'text',
          created_at: moment().subtract(5, 'minutes')
        }
      ],
      unread: 3,
      created_at: moment().subtract(26, 'minutes')
    },
    {
      id: uuid(),
      otherUser: {
        name: 'Adelbert Schoroder',
        avatar: '/images/avatars/volunteers/placeatsapientererum.png',
        active: false,
        lastActivity: moment().subtract(2, 'minutes')
      },
      messages: [
        {
          id: uuid(),
          sender: {
            authUser: false,
            name: 'Adelbert Schoroder',
            avatar: '/images/avatars/volunteers/placeatsapientererum.png'
          },
          content: 'Hi Shen, we should submit the product today',
          contentType: 'text',
          created_at: moment().subtract(2, 'hours')
        },
        {
          id: uuid(),
          sender: {
            authUser: true,
            name: 'Rajakumar Thangavelu',
            avatar: '/images/avatars/volunteers/rajakumar.thangavelu.jpg'
          },
          content: 'Oh, totally forgot about it',
          contentType: 'text',
          created_at: moment()
            .subtract(1, 'hour')
            .subtract(2, 'minutes')
        },
        {
          id: uuid(),
          sender: {
            authUser: true,
            name: 'Rajakumar Thangavelu',
            avatar: '/images/avatars/volunteers/rajakumar.thangavelu.jpg'
          },
          content: 'Alright then',
          contentType: 'text',
          created_at: moment().subtract(1, 'hour')
        }
      ],
      unread: 0,
      created_at: moment().subtract(3, 'hours')
    },
    {
      id: uuid(),
      otherUser: {
        name: 'Florence Bardwell',
        avatar: '/images/avatars/volunteers/praesentiumquinon.png',
        active: true,
        lastActivity: moment()
      },
      messages: [
        {
          id: uuid(),
          sender: {
            authUser: true,
            name: 'Rajakumar Thangavelu',
            avatar: '/images/avatars/volunteers/rajakumar.thangavelu.jpg'
          },
          content:
            'Hi Kwak! I\'ve seen your projects and we can work together on a project. Will send you the details later.',
          contentType: 'text',
          created_at: moment().subtract(3, 'days')
        },
        {
          id: uuid(),
          sender: {
            authUser: false,
            name: 'Florence Bardwell',
            avatar: '/images/avatars/volunteers/praesentiumquinon.png'
          },
          content: 'Haha, right, we\'ll do it',
          contentType: 'text',
          created_at: moment().subtract(2, 'days')
        }
      ],
      unread: 1,
      created_at: moment().subtract(2, 'days')
    },
    {
      id: uuid(),
      otherUser: {
        name: 'Cao Yu',
        avatar: '/images/avatars/volunteers/etquiaadipisci.png',
        active: false,
        lastActivity: moment().subtract(4, 'hours')
      },
      messages: [
        {
          id: uuid(),
          sender: {
            authUser: true,
            name: 'Rajakumar Thangavelu',
            avatar: '/images/avatars/volunteers/rajakumar.thangavelu.jpg'
          },
          content: 'Did you receive my email about the brief?',
          contentType: 'text',
          created_at: moment().subtract(3, 'days')
        },
        {
          id: uuid(),
          sender: {
            authUser: false,
            name: 'Cao Yu',
            avatar: '/images/avatars/volunteers/etquiaadipisci.png'
          },
          content: 'I\'m not sure, but I will check it later',
          contentType: 'text',
          created_at: moment().subtract(2, 'days')
        }
      ],
      unread: 0,
      created_at: moment().subtract(5, 'days')
    },
    {
      id: uuid(),
      otherUser: {
        name: 'Cybill Waskett',
        avatar: '/images/avatars/volunteers/corruptibeataemollitia.png',
        active: true,
        lastActivity: moment()
      },
      messages: [
        {
          id: uuid(),
          sender: {
            authUser: false,
            name: 'Cybill Waskett',
            avatar: '/images/avatars/volunteers/corruptibeataemollitia.png'
          },
          content: 'Hey Shen! I love your projects!!!',
          contentType: 'text',
          created_at: moment().subtract(2, 'days')
        },
        {
          id: uuid(),
          sender: {
            authUser: true,
            name: 'Rajakumar Thangavelu',
            avatar: '/images/avatars/volunteers/rajakumar.thangavelu.jpg'
          },
          content: 'Haha thank you Clarke, I\'m doing our best',
          contentType: 'text',
          created_at: moment().subtract(3, 'days')
        }
      ],
      unread: 0,
      created_at: moment().subtract(5, 'days')
    }
  ]
});

mock.onGet('/api/chat/activity').reply(200, {
  groups: [
    {
      id: 'ngos',
      name: 'NGOs'
    },
    {
      id: 'volunteers',
      name: 'Volunteers'
    }
  ],
  connections: [
    {
      id: uuid(),
      name: 'Ekaterina Tankova',
      avatar: '/images/avatars/volunteers/estfugitaut.png',
      active: false,
      lastActivity: moment().subtract(24, 'minutes'),
      group: 'volunteers'
    },
    {
      id: uuid(),
      name: 'Cao Yu',
      avatar: '/images/avatars/volunteers/etquiaadipisci.png',
      active: true,
      lastActivity: moment(),
      group: 'volunteers'
    },
    {
      id: uuid(),
      name: 'Ashwin Kumar',
      avatar: '/images/avatars/volunteers/ashwin.kumar.jpg',
      active: false,
      lastActivity: moment().subtract(1, 'minutes'),
      group: 'volunteers'
    },
    {
      id: uuid(),
      name: 'Jeevanantham Chellappan',
      avatar: '/images/avatars/volunteers/jeeva.jpg',
      active: true,
      lastActivity: moment(),
      group: 'volunteers'
    },
    {
      id: uuid(),
      name: 'Florence Bardwell',
      avatar: '/images/avatars/volunteers/praesentiumquinon.png',
      active: true,
      lastActivity: moment(),
      group: 'volunteers'
    },
    {
      id: uuid(),
      name: 'Rajakumar Thangavelu',
      avatar: '/images/avatars/volunteers/rajakumar.thangavelu.jpg',
      active: true,
      lastActivity: moment(),
      group: 'volunteers'
    },
    {
      id: uuid(),
      name: 'Cybill Waskett',
      avatar: '/images/avatars/volunteers/corruptibeataemollitia.png',
      active: true,
      lastActivity: moment(),
      group: 'ngos'
    },
    {
      id: uuid(),
      name: 'Adam Denisov',
      avatar: '/images/avatars/volunteers/molestiasseddebitis.png',
      active: false,
      lastActivity: moment().subtract(24, 'minutes'),
      group: 'ngos'
    },
    {
      id: uuid(),
      name: 'Adelbert Schoroder',
      avatar: '/images/avatars/volunteers/placeatsapientererum.png',
      active: true,
      lastActivity: moment(),
      group: 'ngos'
    },
    {
      id: uuid(),
      name: 'Merrile Burgett',
      avatar: '/images/avatars/volunteers/consequaturnoneligendi.png',
      active: false,
      lastActivity: moment().subtract(2, 'days')
    }
  ]
});

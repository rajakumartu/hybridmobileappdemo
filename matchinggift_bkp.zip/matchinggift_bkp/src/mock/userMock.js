import uuid from 'uuid/v1';
import moment from 'moment';
import { colors } from '@material-ui/core';

import mock from 'utils/mock';

mock.onGet('/api/users').reply(200, {
  users: []
});

mock.onGet('/api/users/1/posts').reply(200, {
  posts: [
    {
      id: uuid(),
      type: {
        name: 'Rajakumar Thangavelu',
        avatar: '/images/avatars/volunteers/rajakumar.thangavelu.jpg'
      },
      message: 'Just made this home screen for a project, what-cha thinkin?',
      media: '/images/posts/post_1.jpg',
      liked: true,
      likes: 24,
      comments: [
        {
          id: uuid(),
          type: {
            name: 'Ashwin Kumar',
            avatar: '/images/avatars/volunteers/ashwin.kumar.jpg'
          },
          message: 'Could use some more statistics, but that’s me haha',
          created_at: moment().subtract(3, 'hours')
        },
        {
          id: uuid(),
          type: {
            name: 'Jeevanantham Chellappan',
            avatar: '/images/avatars/volunteers/jeeva.jpg'
          },
          message:
            'Hmm, honestly this looks nice but I would change the shadow though',
          created_at: moment().subtract(2, 'hours')
        }
      ],
      created_at: moment().subtract(4, 'hours')
    },
    {
      id: uuid(),
      type: {
        name: 'Rajakumar Thangavelu',
        avatar: '/images/avatars/volunteers/rajakumar.thangavelu.jpg'
      },
      message:
        'As a human being, you are designed in a way that makes you incapable of experiencing any positive emotion unless you set an aim and progress towards it. What makes you happy is not, in fact, attaining it, but making progress towards it.',
      liked: false,
      likes: 65,
      comments: [
        {
          id: uuid(),
          type: {
            name: 'Cybill Waskett',
            avatar: '/images/avatars/volunteers/corruptibeataemollitia.png'
          },
          message:
            'That’s actually deep. Thanks for the design, would you consider making an interaction?',
          created_at: moment().subtract(3, 'hours')
        },
        {
          id: uuid(),
          type: {
            name: 'Rutledge Nottram',
            avatar: '/images/avatars/volunteers/doloremqueoditnulla.png'
          },
          message: 'It looks nice',
          created_at: moment().subtract(2, 'hours')
        }
      ],
      created_at: moment().subtract(7, 'hours')
    }
  ]
});

mock.onGet('/api/users/1/projects').reply(200, {
  projects: [
    {
      id: uuid(),
      title: 'Student Scholarship',
      ngo: {
        name: 'Team Everest',
      },
      need: {
        type: 'funding',
        price: '15,750',
        currency: '₹'
      },
      type: {
        name: 'Education',
        avatar: '/images/avatars/projects/funding.png'
      },
      mode: 'Virtual',
      location: 'Chennai',
      status: 'In progress',
      wishes: 5,
      tags: [
        {
          text: 'Funding',
          color: colors.red[600]
        }
      ],
      start_date: moment(),
      end_date: moment(),
      updated_at: moment().subtract(24, 'minutes')
    },
    {
      id: uuid(),
      title: 'Story Telling',
      ngo: {
        name: 'Team Everest',
      },
      need: {
        type: 'skill',
        hours: '100'
      },
      type: {
        name: 'Education',
        avatar: '/images/avatars/projects/skill.png'
      },
      mode: 'Virtual',
      location: 'Chennai',
      status: 'In progress',
      wishes: 5,
      tags: [
        {
          text: 'Skills',
          color: colors.blue[600]
        }
      ],
      start_date: moment(),
      end_date: moment(),
      updated_at: moment().subtract(24, 'minutes')
    },
    {
      id: uuid(),
      title: 'Tree Plantation',
      ngo: {
        name: 'Chennai Volunteers',
      },
      need: {
        type: 'volunteers',
        count: 40
      },
      type: {
        name: 'Environment',
        avatar: '/images/avatars/projects/environment2.jpg'
      },
      mode: 'Physical',
      location: 'Chennai',
      status: 'In progress',
      wishes: 5,
      tags: [
        {
          text: 'Environment',
          color: colors.green[600]
        }
      ],
      start_date: moment(),
      end_date: moment(),
      updated_at: moment().subtract(24, 'minutes')
    }
  ]
});

mock.onGet('/api/users/1/reviews').reply(200, {
  reviews: [
    {
      id: uuid(),
      rating: 4,
      message:
        'Shen was really great during the all time session we created the project',
      reviewer: {
        name: 'Ekaterina Tankova',
        avatar: '/images/avatars/volunteers/estfugitaut.png'
      },
      project: {
        title: 'Mella Full Screen Slider',
        price: '5,240.00'
      },
      pricePerHour: '43.00',
      hours: 31,
      currency: '$',
      created_at: moment().subtract(4, 'hours')
    },
    {
      id: uuid(),
      rating: 5,
      reviewer: {
        name: 'Cao Yu',
        avatar: '/images/avatars/volunteers/etquiaadipisci.png'
      },
      project: {
        title: 'Dashboard Design',
        price: '3,680.00'
      },
      pricePerHour: '38.00',
      hours: 76,
      currency: '$',
      message:
        'Being the savage\'s bowsman, that is, the person who pulled the bow-oar in his boat (the second one from forward), it was my cheerful duty to attend upon him while taking that hard-scrabble scramble upon the dead whale\'s back. You have seen Italian organ-boys holding a dancing-ape by a long cord. Just so, from the ship\'s steep side, did I hold Queequeg down there in the sea, by what is technically called in the fishery a monkey-rope, attached to a strong strip of canvas belted round his waist.',
      created_at: moment().subtract(8, 'days')
    }
  ]
});

mock.onGet('/api/users/1/connections').reply(200, {
  connections: [
    {
      id: uuid(),
      name: 'Ekaterina Tankova',
      avatar: '/images/avatars/volunteers/estfugitaut.png',
      common: 12,
      status: 'connected'
    },
    {
      id: uuid(),
      name: 'Cao Yu',
      avatar: '/images/avatars/volunteers/etquiaadipisci.png',
      common: 10,
      status: 'rejected'
    },
    {
      id: uuid(),
      name: 'Rutledge Nottram',
      avatar: '/images/avatars/volunteers/doloremqueoditnulla.png',
      common: 8,
      status: 'pending'
    },
    {
      id: uuid(),
      name: 'Adam Denisov',
      avatar: '/images/avatars/volunteers/molestiasseddebitis.png',
      common: 5,
      status: 'not_connected'
    },
    {
      id: uuid(),
      name: 'Jeevanantham Chellappan',
      avatar: '/images/avatars/volunteers/jeeva.jpg',
      common: 1,
      status: 'connected'
    }
  ]
});

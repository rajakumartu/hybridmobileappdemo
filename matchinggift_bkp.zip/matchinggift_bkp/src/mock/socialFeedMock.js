import uuid from 'uuid/v1';
import moment from 'moment';

import mock from 'utils/mock';

mock.onGet('/api/social-feed').reply(200, {
  posts: [
    {
      id: uuid(),
      type: {
        name: 'Florence Bardwell',
        avatar: '/images/avatars/volunteers/praesentiumquinon.png'
      },
      message: 'Hey guys! What\'s your favorite framework?',
      liked: true,
      likes: 1,
      comments: [
        {
          id: uuid(),
          type: {
            name: 'Merrile Burgett',
            avatar: '/images/avatars/volunteers/consequaturnoneligendi.png'
          },
          message: 'I\'ve been using Angular for the past 3 years',
          created_at: moment().subtract(3, 'hours')
        }
      ],
      created_at: moment().subtract(16, 'minutes')
    },
    {
      id: uuid(),
      type: {
        name: 'Rajakumar Thangavelu',
        avatar: '/images/avatars/volunteers/rajakumar.thangavelu.jpg'
      },
      message: 'Just made this home screen for a project, what-cha thinkin?',
      media: '/images/posts/post_1.jpg',
      liked: true,
      likes: 24,
      comments: [
        {
          id: uuid(),
          type: {
            name: 'Ashwin Kumar',
            avatar: '/images/avatars/volunteers/ashwin.kumar.jpg'
          },
          message: 'Could use some more statistics, but that’s me haha',
          created_at: moment().subtract(3, 'hours')
        },
        {
          id: uuid(),
          type: {
            name: 'Jeevanantham Chellappan',
            avatar: '/images/avatars/volunteers/jeeva.jpg'
          },
          message:
            'Hmm, honestly this looks nice but I would change the shadow though',
          created_at: moment().subtract(2, 'hours')
        }
      ],
      created_at: moment().subtract(4, 'hours')
    },
    {
      id: uuid(),
      type: {
        name: 'Rajakumar Thangavelu',
        avatar: '/images/avatars/volunteers/rajakumar.thangavelu.jpg'
      },
      message:
        'As a human being, you are designed in a way that makes you incapable of experiencing any positive emotion unless you set an aim and progress towards it. What makes you happy is not, in fact, attaining it, but making progress towards it.',
      liked: false,
      likes: 65,
      comments: [
        {
          id: uuid(),
          type: {
            name: 'Cybill Waskett',
            avatar: '/images/avatars/volunteers/corruptibeataemollitia.png'
          },
          message:
            'That’s actually deep. Thanks for the design, would you consider making an interaction?',
          created_at: moment().subtract(3, 'hours')
        },
        {
          id: uuid(),
          type: {
            name: 'Rutledge Nottram',
            avatar: '/images/avatars/volunteers/doloremqueoditnulla.png'
          },
          message: 'Oh... so sentimental',
          created_at: moment().subtract(2, 'hours')
        }
      ],
      created_at: moment().subtract(7, 'hours')
    }
  ]
});

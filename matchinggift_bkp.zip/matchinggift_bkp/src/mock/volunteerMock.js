import uuid from 'uuid/v1';
import moment from 'moment';

import mock from 'utils/mock';

mock.onGet('/api/management/volunteers').reply(200, {
  volunteers: [
    {
      id: 1,
      name: 'Rajakumar Thangavelu',
      email: 'rajakumar.thangavelu@gmail.com',
      avatar: '/images/avatars/volunteers/rajakumar.thangavelu.jpg',
      profession: 'Working',
      projects: 1,
      gender: 'Male',
      location: 'Thiruvanmiyur, Chennai'
    }, {
      id: 2,
      name: 'Ashwin Kumar',
      email: 'mchawner1@github.com',
      gender: 'Male',
      avatar: '/images/avatars/volunteers/ashwin.kumar.jpg',
      profession: 'Information Systems Manager',
      location: 'Anna Nagar, Chennai',
      projects: 2
    }, {
      id: 3,
      name: 'Jeevanantham Chellappan',
      email: 'cphillpotts2@youtube.com',
      gender: 'Male',
      avatar: '/images/avatars/volunteers/jeeva.jpg',
      profession: 'Assistant Manager',
      location: 'Tambaram, Chennai',
      projects: 3
    }, {
      id: 4,
      name: 'Cybill Waskett',
      email: 'cwaskett3@purevolume.com',
      gender: 'Female',
      avatar: 'https://robohash.org/corruptibeataemollitia.bmp?size=50x50&set=set1',
      profession: 'Environmental Specialist',
      location: 'Mokil',
      projects: 3
    }, {
      id: 5,
      name: 'Rutledge Nottram',
      email: 'rnottram4@yandex.ru',
      gender: 'Male',
      avatar: 'https://robohash.org/doloremqueoditnulla.jpg?size=50x50&set=set1',
      profession: 'Chief Design Engineer',
      location: 'Kuantan',
      projects: 1
    }, {
      id: 6,
      name: 'Magdaia Cheson',
      email: 'mcheson5@symantec.com',
      gender: 'Female',
      avatar: 'https://robohash.org/etquiaadipisci.bmp?size=50x50&set=set1',
      profession: 'Environmental Specialist',
      location: 'Argotirto Krajan',
      projects: 3
    }, {
      id: 7,
      name: 'Benetta McGing',
      email: 'bmcging6@g.co',
      gender: 'Female',
      avatar: 'https://robohash.org/estfugitaut.jpg?size=50x50&set=set1',
      profession: 'Paralegal',
      location: 'Kariaí',
      projects: 3
    }, {
      id: 8,
      name: 'Ian Stitcher',
      email: 'istitcher7@sakura.ne.jp',
      gender: 'Male',
      avatar: 'https://robohash.org/molestiasseddebitis.png?size=50x50&set=set1',
      profession: 'Environmental Specialist',
      location: 'Bengtsfors',
      projects: 3
    }, {
      id: 9,
      name: 'Adelbert Schoroder',
      email: 'aschoroder8@youtu.be',
      gender: 'Male',
      avatar: 'https://robohash.org/placeatsapientererum.png?size=50x50&set=set1',
      profession: 'Nurse Practicioner',
      location: 'Cane',
      projects: 3
    }, {
      id: 10,
      name: 'Florence Bardwell',
      email: 'fbardwell9@google.com.hk',
      gender: 'Female',
      avatar: 'https://robohash.org/praesentiumquinon.png?size=50x50&set=set1',
      profession: 'Compensation Analyst',
      location: 'Port Antonio',
      projects: 2
    }, {
      id: 11,
      name: 'Hilliary Travis',
      email: 'htravisa@eepurl.com',
      gender: 'Female',
      avatar: 'https://robohash.org/consequaturnoneligendi.bmp?size=50x50&set=set1',
      profession: 'Recruiting Manager',
      location: 'Timashëvsk',
      projects: 1
    }, {
      id: 12,
      name: 'Vito Scourfield',
      email: 'vscourfieldb@ebay.co.uk',
      gender: 'Male',
      avatar: 'https://robohash.org/quicumearum.png?size=50x50&set=set1',
      profession: 'Technical Writer',
      location: 'Jianxin',
      projects: 1
    }, {
      id: 13,
      name: 'Glennis Brew',
      email: 'gbrewc@photobucket.com',
      gender: 'Female',
      avatar: 'https://robohash.org/vitaeaccusantiumdicta.jpg?size=50x50&set=set1',
      profession: 'Accountant II',
      location: 'Rothesay Bay',
      projects: 2
    }, {
      id: 14,
      name: 'Chane Alldis',
      email: 'calldisd@wiley.com',
      gender: 'Male',
      avatar: 'https://robohash.org/liberoautemeum.bmp?size=50x50&set=set1',
      profession: 'Systems Administrator I',
      location: 'Pisangkemeng',
      projects: 3
    }, {
      id: 15,
      name: 'Sebastien Muckle',
      email: 'smucklee@google.ru',
      gender: 'Male',
      avatar: 'https://robohash.org/dolorveniamet.bmp?size=50x50&set=set1',
      profession: 'Senior Quality Engineer',
      location: 'Xianzong',
      projects: 3
    }, {
      id: 16,
      name: 'Katrinka Kimblin',
      email: 'kkimblinf@fema.gov',
      gender: 'Female',
      avatar: 'https://robohash.org/reprehenderittemporeculpa.bmp?size=50x50&set=set1',
      profession: 'Accountant IV',
      location: 'Jiuzhen',
      projects: 2
    }, {
      id: 17,
      name: 'Win Giacobelli',
      email: 'wgiacobellig@usa.gov',
      gender: 'Male',
      avatar: 'https://robohash.org/etnondeleniti.bmp?size=50x50&set=set1',
      profession: 'Software Test Engineer IV',
      location: 'Tost',
      projects: 1
    }, {
      id: 18,
      name: 'Coleen Alenichev',
      email: 'calenichevh@free.fr',
      gender: 'Female',
      avatar: 'https://robohash.org/nonquibusdameos.png?size=50x50&set=set1',
      profession: 'Executive Secretary',
      location: 'Andoany',
      projects: 3
    }, {
      id: 19,
      name: 'Karlyn Duchan',
      email: 'kduchani@prnewswire.com',
      gender: 'Female',
      avatar: 'https://robohash.org/enimconsecteturvoluptatum.bmp?size=50x50&set=set1',
      profession: 'Design Engineer',
      location: 'Huangshapu',
      projects: 2
    }, {
      id: 20,
      name: 'Kayle Meegin',
      email: 'kmeeginj@wikispaces.com',
      gender: 'Female',
      avatar: 'https://robohash.org/doloremetfugiat.png?size=50x50&set=set1',
      profession: 'Help Desk Operator',
      location: 'Tammela',
      projects: 3
    }]
});

mock.onGet('/api/management/customers/1/summary').reply(200, {
  summary: {
    name: 'Ekaterina Tankova',
    email: 'ekaterina@devias.io',
    phone: '+55 748 327 439',
    state: 'Alabama',
    country: 'United States',
    zipCode: '240355',
    address1: 'Street John Wick, no. 7',
    address2: 'House #25',
    iban: '4142 **** **** **** ****',
    autoCC: false,
    verified: true,
    currency: '$',
    invoices: [
      {
        id: uuid(),
        type: 'paid',
        value: 10.0
      },
      {
        id: uuid(),
        type: 'paid',
        value: 15.0
      },
      {
        id: uuid(),
        type: 'due',
        value: 5
      },
      {
        id: uuid(),
        type: 'income',
        value: 10.0
      }
    ],
    vat: 19,
    balance: 0,
    emails: [
      {
        id: uuid(),
        description: 'Order confirmation',
        created_at: moment()
          .subtract(3, 'days')
          .subtract(5, 'hours')
          .subtract(34, 'minutes')
      },
      {
        id: uuid(),
        description: 'Order confirmation',
        created_at: moment()
          .subtract(4, 'days')
          .subtract(11, 'hours')
          .subtract(49, 'minutes')
      }
    ]
  }
});

mock.onGet('/api/management/customers/1/invoices').reply(200, {
  invoices: [
    {
      id: uuid(),
      date: moment(),
      description: 'Freelancer Subscription (12/05/2019 - 11/06/2019)',
      paymentMethod: 'Credit Card',
      value: '5.25',
      currency: '$',
      status: 'paid'
    },
    {
      id: uuid(),
      date: moment(),
      description: 'Freelancer Subscription (12/05/2019 - 11/06/2019)',
      paymentMethod: 'Credit Card',
      value: '5.25',
      currency: '$',
      status: 'paid'
    }
  ]
});

mock.onGet('/api/management/customers/1/logs').reply(200, {
  logs: [
    {
      id: uuid(),
      status: 200,
      method: 'POST',
      route: '/api/purchase',
      desc: 'Purchase',
      IP: '84.234.243.42',
      created_at: moment()
        .subtract(2, 'days')
        .subtract(2, 'minutes')
        .subtract(56, 'seconds')
    },
    {
      id: uuid(),
      status: 522,
      error: 'Invalid credit card',
      method: 'POST',
      route: '/api/purchase',
      desc: 'Purchase',
      IP: '84.234.243.42',
      created_at: moment()
        .subtract(2, 'days')
        .subtract(2, 'minutes')
        .subtract(56, 'seconds')
    },
    {
      id: uuid(),
      status: 200,
      method: 'DELETE',
      route: '/api/products/d65654e/remove',
      desc: 'Cart remove',
      IP: '84.234.243.42',
      created_at: moment()
        .subtract(2, 'days')
        .subtract(8, 'minutes')
        .subtract(23, 'seconds')
    },
    {
      id: uuid(),
      status: 200,
      method: 'GET',
      route: '/api/products/d65654e/add',
      desc: 'Cart add',
      IP: '84.234.243.42',
      created_at: moment()
        .subtract(2, 'days')
        .subtract(20, 'minutes')
        .subtract(54, 'seconds')
    },
    {
      id: uuid(),
      status: 200,
      method: 'GET',
      route: '/api/products/c85727f/add',
      desc: 'Cart add',
      IP: '84.234.243.42',
      created_at: moment()
        .subtract(2, 'days')
        .subtract(34, 'minutes')
        .subtract(16, 'seconds')
    },
    {
      id: uuid(),
      status: 200,
      method: 'GET',
      route: '/api/products/c85727f',
      desc: 'View product',
      IP: '84.234.243.42',
      created_at: moment()
        .subtract(2, 'days')
        .subtract(54, 'minutes')
        .subtract(30, 'seconds')
    },
    {
      id: uuid(),
      status: 200,
      method: 'GET',
      route: '/api/products',
      desc: 'Get products',
      IP: '84.234.243.42',
      created_at: moment()
        .subtract(2, 'days')
        .subtract(56, 'minutes')
        .subtract(40, 'seconds')
    },
    {
      id: uuid(),
      status: 200,
      method: 'POST',
      route: '/api/login',
      desc: 'Login',
      IP: '84.234.243.42',
      created_at: moment()
        .subtract(2, 'days')
        .subtract(57, 'minutes')
        .subtract(5, 'seconds')
    }
  ]
});

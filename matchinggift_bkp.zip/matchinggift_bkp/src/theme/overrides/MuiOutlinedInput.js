export default {
  root: {},
  notchedOutline: {
    borderColor: 'rgba(0,0,0,0.15)'
  }
};

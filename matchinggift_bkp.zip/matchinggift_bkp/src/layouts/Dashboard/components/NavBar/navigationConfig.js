/* eslint-disable react/no-multi-comp */
/* eslint-disable react/display-name */
import React from 'react';
import { colors } from '@material-ui/core';
import BarChartIcon from '@material-ui/icons/BarChart';
import CalendarTodayIcon from '@material-ui/icons/CalendarToday';
import ChatIcon from '@material-ui/icons/ChatOutlined';
import DashboardIcon from '@material-ui/icons/DashboardOutlined';
import FolderIcon from '@material-ui/icons/FolderOutlined';
import HomeIcon from '@material-ui/icons/HomeOutlined';
import PeopleIcon from '@material-ui/icons/PeopleOutlined';
import PersonIcon from '@material-ui/icons/PersonOutlined';

import { Label } from 'components';

export default [
  {
    title: 'Pages',
    pages: [
      {
        title: 'Overview',
        href: '/overview',
        icon: HomeIcon
      },
      {
        title: 'Covid 19 Dashboard',
        href: '/dashboards',
        icon: DashboardIcon,
        children: [
          {
            title: 'Aid India',
            href: '/dashboards/default'
          },
          {
            title: 'Chennai Volunteers',
            href: '/dashboards/analytics'
          }
        ]
      },
      {
        title: 'Management',
        href: '/management',
        icon: BarChartIcon,
        children: [
          // {
          //   title: 'Customers',
          //   href: '/management/customers'
          // },
          {
            title: 'Volunteers',
            href: '/management/volunteers'
          },

          {
            title: 'NGOs',
            href: '/management/ngos'
          },
          // {
          //   title: 'Customer Details',
          //   href: '/management/customers/1/summary'
          // },
          {
            title: 'Projects',
            href: '/management/projects'
          },
          {
            title: 'Wishes',
            href: '/management/wishes'
          // },
          // {
          //   title: 'Orders',
          //   href: '/management/orders'
          // },
          // {
          //   title: 'Order Details',
          //   href: '/management/orders/1'
          }
        ]
      },
      {
        title: 'Social Feed',
        href: '/social-feed',
        icon: PeopleIcon
      },
      {
        title: 'Profile',
        href: '/profile',
        icon: PersonIcon,
        children: [
          {
            title: 'Timeline',
            href: '/profile/1/timeline'
          },
          {
            title: 'Connections',
            href: '/profile/1/connections'
          },
          // {
          //   title: 'Projects',
          //   href: '/profile/1/projects'
          // },
          // {
          //   title: 'Reviews',
          //   href: '/profile/1/reviews'
          // }
        ]
      },
      {
        title: 'Project',
        href: '/projects',
        icon: FolderIcon,
        children: [
          {
            title: 'Browse',
            href: '/projects'
          },
          {
            title: 'Create',
            href: '/projects/create'
          },
          // {
          //   title: 'Overview',
          //   href: '/projects/1/overview'
          // },
          // {
          //   title: 'Files',
          //   href: '/projects/1/files'
          // },
          // {
          //   title: 'Activity',
          //   href: '/projects/1/activity'
          // },
          // {
          //   title: 'Subscribers',
          //   href: '/projects/1/subscribers'
          // }
        ]
      },
      {
        title: 'Calendar',
        href: '/calendar',
        icon: CalendarTodayIcon,
        label: () => <Label color={colors.green[500]}>New</Label>
      }
    ]
  }
];
